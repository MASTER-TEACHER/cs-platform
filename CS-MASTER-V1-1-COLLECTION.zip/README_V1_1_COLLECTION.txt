CS MASTER v1.1 SOURCE COLLECTION

Purpose:
- Feedback / Report a Problem
- Admin issue management
- Notification foundation
- GDPR/privacy controls
- Retention/deletion architecture
- Security hardening
- Audit logging
- App Check readiness
- School tenancy / authorization review
- Public/legal integration
- Verification integration

Secrets deliberately excluded.
Do not include .env.local or Firebase Admin credentials.
